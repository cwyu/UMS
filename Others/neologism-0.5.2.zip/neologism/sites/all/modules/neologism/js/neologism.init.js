if( Drupal.jsEnabled ) {
	// declare Neologism namespace
	var Neologism = {};
}