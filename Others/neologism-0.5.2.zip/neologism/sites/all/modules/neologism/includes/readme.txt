In this directory are stored all the external libraries used by Neologism.

